IMPORTANT!

Update 2025-07-15:

This application is fully portable and stealth by default.

--------------------------------------------------------------------

- Antivirus false positive detection

If your antivirus detect Videomass.exe as malicious, please submit 
the Videomass.exe file to your antivirus vendor for advanced analysis
and making a False Positive claim.
Thank you.
---------------------------------------------------------------------

IMPORTANT

ffmpeg.exe, ffprobe.exe, ffplay.exe are required (minimum version
5.1 or higher).

FFmpeg executables are not included on this archive. 
Please install FFmpeg manually or provide a copy of the 
executables compatible with your operating system architecture.
For more informations or to download these executables visit the 
following web pages:
	
FFmpeg:
	<https://www.gyan.dev/ffmpeg/>
    	<https://github.com/BtbN/FFmpeg-Builds/releases>

NOTES

Additional installation instructions can be found in the README file
included in the "_internal\FFMPEG" folder of this archive.
---------------------------------------------------------------------

To start Videomass, double click on the Videomass.exe .

Gianluca (jeanslack) Pernigotto

